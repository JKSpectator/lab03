/**
 */
package org.rm2pt.sample.basicfamily.metamodel.basicfamily;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Woman</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.rm2pt.sample.basicfamily.metamodel.basicfamily.BasicfamilyPackage#getWoman()
 * @model
 * @generated
 */
public interface Woman extends Person {
} // Woman
