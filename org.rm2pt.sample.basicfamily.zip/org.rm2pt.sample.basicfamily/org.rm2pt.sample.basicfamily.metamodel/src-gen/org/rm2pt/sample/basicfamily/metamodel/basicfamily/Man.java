/**
 */
package org.rm2pt.sample.basicfamily.metamodel.basicfamily;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Man</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.rm2pt.sample.basicfamily.metamodel.basicfamily.BasicfamilyPackage#getMan()
 * @model
 * @generated
 */
public interface Man extends Person {
} // Man
